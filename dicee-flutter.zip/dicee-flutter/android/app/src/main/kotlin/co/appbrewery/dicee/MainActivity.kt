package co.appbrewery.dicee

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
